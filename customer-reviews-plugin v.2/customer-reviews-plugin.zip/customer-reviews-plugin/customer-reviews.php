<?php
/**
 * Plugin Name: Customer Love Reviews
 * Plugin URI: https://github.com/Markjonel02/customer-reviews-wordpress.git
 * Description: Beautiful customer review plugin with image uploads and carousel display
 * Version: 1.0.0
 * Author: Mark Relles
 * Author URI: https://www.linkedin.com/public-profile/settings?trk=d_flagship3_profile_self_view_public_profile
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: customer-reviews
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('CR_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('CR_PLUGIN_URL', plugin_dir_url(__FILE__));
define('CR_PLUGIN_VERSION', '1.0.0');

// Include necessary files
require_once CR_PLUGIN_DIR . 'includes/database.php';
require_once CR_PLUGIN_DIR . 'includes/admin.php';
require_once CR_PLUGIN_DIR . 'includes/frontend.php';

class Customer_Love_Reviews {
    
    public function __construct() {
        // Activation and deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // Admin initialization
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        
        // Frontend initialization
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_scripts'));
        add_shortcode('customer_reviews', array($this, 'render_reviews_shortcode'));
        
        // AJAX handlers
        add_action('wp_ajax_submit_review', array($this, 'handle_submit_review'));
        add_action('wp_ajax_nopriv_submit_review', array($this, 'handle_submit_review'));
        add_action('wp_ajax_load_reviews', 'cr_ajax_load_reviews');
        add_action('wp_ajax_nopriv_load_reviews', 'cr_ajax_load_reviews');
        
        // Bulk action handlers
        add_action('wp_ajax_cr_bulk_approve', array($this, 'handle_bulk_approve'));
        add_action('wp_ajax_cr_bulk_reject', array($this, 'handle_bulk_reject'));
        add_action('wp_ajax_cr_bulk_delete', array($this, 'handle_bulk_delete'));
    }
    
    public function activate() {
        cr_create_database_tables();
        flush_rewrite_rules();
    }
    
    public function deactivate() {
        flush_rewrite_rules();
    }
    
    public function add_admin_menu() {
        add_menu_page(
            'Customer Reviews',
            'Customer Reviews',
            'manage_options',
            'customer-reviews',
            array($this, 'admin_page'),
            'dashicons-star-filled',
            25
        );
    }
    
    public function admin_page() {
        cr_admin_page();
    }
    
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'customer-reviews') === false) {
            return;
        }
        
        wp_enqueue_style('cr-admin-css', CR_PLUGIN_URL . 'assets/css/admin.css', array(), CR_PLUGIN_VERSION);
        wp_enqueue_script('cr-admin-js', CR_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), CR_PLUGIN_VERSION, true);
    }
    
    public function enqueue_frontend_scripts() {
        wp_enqueue_style('cr-frontend-css', CR_PLUGIN_URL . 'assets/css/frontend.css', array(), CR_PLUGIN_VERSION);
        wp_enqueue_script('cr-frontend-js', CR_PLUGIN_URL . 'assets/js/frontend.js', array('jquery'), CR_PLUGIN_VERSION, true);
        
        wp_localize_script('cr-frontend-js', 'crData', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('cr_nonce')
        ));
    }
    
    public function render_reviews_shortcode($atts) {
        return cr_render_reviews_carousel($atts);
    }
    
    public function handle_submit_review() {
        check_ajax_referer('cr_nonce', 'nonce');
        
        $name = sanitize_text_field($_POST['name'] ?? '');
        $email = sanitize_email($_POST['email'] ?? '');
        $text = sanitize_textarea_field($_POST['text'] ?? '');
        $rating = intval($_POST['rating'] ?? 5);
        $is_anonymous = isset($_POST['is_anonymous']) ? sanitize_text_field($_POST['is_anonymous']) : 'no';
        
        if (empty($text)) {
            wp_send_json_error('Please write a review');
        }
        
        if ($is_anonymous === 'no' && empty($name)) {
            wp_send_json_error('Please enter your name or check "Post as Anonymous"');
        }
        
        if ($is_anonymous === 'no' && empty($email)) {
            wp_send_json_error('Please enter your email or check "Post as Anonymous"');
        }
        
        $image_id = 0;
        $video_url = '';
        
        // Handle image upload
        if (!empty($_FILES['image']['name'])) {
            // Check if uploads directory exists and is writable
            if (!function_exists('wp_handle_upload')) {
                require_once(ABSPATH . 'wp-admin/includes/file.php');
            }
            
            // Allowed file types
            $allowed_types = array('jpg|jpeg|jpe' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif', 'webp' => 'image/webp');
            
            // Move the uploaded file to temp location
            $overrides = array('test_form' => false);
            $movefile = wp_handle_upload($_FILES['image'], $overrides);
            
            if (isset($movefile['error'])) {
                wp_send_json_error('Image upload failed: ' . $movefile['error']);
            }
            
            if (isset($movefile['file'])) {
                // Insert the attachment
                require_once(ABSPATH . 'wp-admin/includes/image.php');
                
                $upload_dir = wp_upload_dir();
                $file_path = $movefile['file'];
                $file_url = $movefile['url'];
                
                // Create attachment post
                $attachment = array(
                    'guid' => $file_url,
                    'post_mime_type' => $movefile['type'],
                    'post_title' => preg_replace('/\.[^.]+$/', '', basename($file_path)),
                    'post_content' => '',
                    'post_status' => 'inherit'
                );
                
                $image_id = wp_insert_attachment($attachment, $file_path);
                
                if (is_wp_error($image_id)) {
                    wp_send_json_error('Failed to save image: ' . $image_id->get_error_message());
                }
                
                // Generate attachment metadata
                $attach_data = wp_generate_attachment_metadata($image_id, $file_path);
                if (!is_wp_error($attach_data)) {
                    wp_update_attachment_metadata($image_id, $attach_data);
                }
            }
        }
        
        // Handle video URL
        if (!empty($_POST['video_url'])) {
            $video_url = esc_url_raw($_POST['video_url']);
        }
        
        // Don't mask on save - keep original name/email in DB, masking happens on display
        // Auto-approve for logged-in admin/shop manager, else pending
        $user = wp_get_current_user();
        $auto_approve = ($user->ID > 0 && (in_array('administrator', (array) $user->roles) || in_array('shop_manager', (array) $user->roles)));
        
        $review_data = array(
            'name' => $name,  // Keep original name
            'email' => $is_anonymous === 'yes' ? 'anonymous@example.com' : $email,  // But use placeholder email if anonymous
            'text' => $text,
            'rating' => $rating,
            'image_id' => $image_id,
            'video_url' => $video_url,
            'is_anonymous' => $is_anonymous,  // Store the flag
            'status' => $auto_approve ? 'approved' : 'pending'
        );
        
        $review_id = cr_add_review($review_data);
        
        if ($review_id) {
            $message = $auto_approve ? 'Review posted successfully!' : 'Review submitted! It will appear after admin approval.';
            wp_send_json_success(array(
                'message' => $message,
                'review_id' => $review_id,
                'auto_approved' => $auto_approve
            ));
        } else {
            wp_send_json_error('Failed to submit review');
        }
    }
    
    // Bulk Approve Handler
    public function handle_bulk_approve() {
        check_ajax_referer('cr_bulk_actions_nonce', 'nonce', true);
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        
        $ids = isset($_POST['ids']) ? array_map('intval', $_POST['ids']) : array();
        
        if (empty($ids)) {
            wp_send_json_error('No reviews selected');
        }
        
        global $wpdb;
        $table = $wpdb->prefix . 'customer_reviews';
        
        foreach ($ids as $id) {
            $wpdb->update($table, array('status' => 'approved'), array('id' => $id), array('%s'), array('%d'));
        }
        
        wp_send_json_success('Reviews approved');
    }
    
    // Bulk Reject Handler
    public function handle_bulk_reject() {
        check_ajax_referer('cr_bulk_actions_nonce', 'nonce', true);
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        
        $ids = isset($_POST['ids']) ? array_map('intval', $_POST['ids']) : array();
        
        if (empty($ids)) {
            wp_send_json_error('No reviews selected');
        }
        
        global $wpdb;
        $table = $wpdb->prefix . 'customer_reviews';
        
        foreach ($ids as $id) {
            $wpdb->update($table, array('status' => 'rejected'), array('id' => $id), array('%s'), array('%d'));
        }
        
        wp_send_json_success('Reviews rejected');
    }
    
    // Bulk Delete Handler
    public function handle_bulk_delete() {
        check_ajax_referer('cr_bulk_actions_nonce', 'nonce', true);
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        
        $ids = isset($_POST['ids']) ? array_map('intval', $_POST['ids']) : array();
        
        if (empty($ids)) {
            wp_send_json_error('No reviews selected');
        }
        
        global $wpdb;
        $table = $wpdb->prefix . 'customer_reviews';
        
        foreach ($ids as $id) {
            $wpdb->delete($table, array('id' => $id), array('%d'));
        }
        
        wp_send_json_success('Reviews deleted');
    }
}

// Initialize plugin
new Customer_Love_Reviews();
