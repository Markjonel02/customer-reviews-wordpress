<?php

if (!defined('ABSPATH')) {
    exit;
}

function cr_admin_page() {
    if (!current_user_can('manage_options')) {
        wp_die('Unauthorized');
    }
    
    $action = isset($_GET['action']) ? sanitize_key($_GET['action']) : 'list';
    $review_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    
    // Handle status updates
    if (isset($_GET['status_action'])) {
        $status_action = sanitize_key($_GET['status_action']);
        $id = intval($_GET['id']);
        
        if ($status_action === 'approve') {
            cr_update_review_status($id, 'approved');
        } elseif ($status_action === 'reject') {
            cr_update_review_status($id, 'rejected');
        } elseif ($status_action === 'delete') {
            cr_delete_review($id);
        }
        
        wp_safe_remote_get(admin_url('admin.php?page=customer-reviews'));
    }
    
    // Handle review edit form submission
    if (isset($_POST['action']) && $_POST['action'] === 'save_review' && check_admin_referer('cr_edit_nonce', 'cr_nonce')) {
        $id = intval($_POST['review_id']);
        
        // Get form data
        $name = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : 'Admin Review';
        $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : 'admin@localhost';
        $text = isset($_POST['text']) ? sanitize_textarea_field($_POST['text']) : '';
        $rating = isset($_POST['rating']) ? intval($_POST['rating']) : 5;
        $video_url = isset($_POST['video_url']) ? esc_url_raw($_POST['video_url']) : '';
        $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : 'pending';
        
        // Only text is required
        if (empty($text)) {
            echo '<div class="notice notice-error is-dismissible"><p>Error: Review text is required.</p></div>';
        } elseif ($rating < 1 || $rating > 5) {
            echo '<div class="notice notice-error is-dismissible"><p>Error: Rating must be between 1 and 5.</p></div>';
        } else {
            $review_data = array(
                'name' => $name,
                'email' => $email,
                'text' => $text,
                'rating' => $rating,
                'video_url' => $video_url,
                'status' => $status
            );
            
            $image_id = 0;
            
            // Handle image upload
            if (!empty($_FILES['image_upload']['name'])) {
                if (!function_exists('wp_handle_upload')) {
                    require_once(ABSPATH . 'wp-admin/includes/file.php');
                }
                
                $overrides = array('test_form' => false);
                $movefile = wp_handle_upload($_FILES['image_upload'], $overrides);
                
                if (isset($movefile['error'])) {
                    echo '<div class="notice notice-warning is-dismissible"><p>Image upload warning: ' . esc_html($movefile['error']) . '</p></div>';
                } elseif (isset($movefile['file'])) {
                    if (!function_exists('wp_insert_attachment')) {
                        require_once(ABSPATH . 'wp-admin/includes/image.php');
                    }
                    
                    $file_path = $movefile['file'];
                    $file_url = $movefile['url'];
                    
                    $attachment = array(
                        'guid' => $file_url,
                        'post_mime_type' => $movefile['type'],
                        'post_title' => preg_replace('/\.[^.]+$/', '', basename($file_path)),
                        'post_content' => '',
                        'post_status' => 'inherit'
                    );
                    
                    $image_id = wp_insert_attachment($attachment, $file_path);
                    
                    if (!is_wp_error($image_id)) {
                        $attach_data = wp_generate_attachment_metadata($image_id, $file_path);
                        if (!is_wp_error($attach_data)) {
                            wp_update_attachment_metadata($image_id, $attach_data);
                        }
                        $review_data['image_id'] = $image_id;
                    }
                }
            }
            
            if ($id === 0) {
                // Adding new review
                $review_data['is_anonymous'] = 'no';
                $result = cr_add_review($review_data);
                if ($result) {
                    echo '<div class="notice notice-success is-dismissible"><p>✓ Review #' . intval($result) . ' added successfully!</p></div>';
                } else {
                    echo '<div class="notice notice-error is-dismissible"><p>Error: Failed to add review to database. This might be a server issue. Check: 1) File permissions on /wp-content/uploads/, 2) MySQL connection, 3) wp-content/debug.log</p></div>';
                }
            } else {
                // Updating existing review
                $result = cr_update_review($id, $review_data);
                if ($result !== false) {
                    echo '<div class="notice notice-success is-dismissible"><p>✓ Review updated successfully!</p></div>';
                } else {
                    echo '<div class="notice notice-error is-dismissible"><p>Error: Failed to update review.</p></div>';
                }
            }
        }
    }
    
    ?>
    <div class="wrap cr-admin-wrap">
        <h1>Customer Love Reviews</h1>
        
        <div class="nav-tab-wrapper">
            <a href="?page=customer-reviews&action=list" class="nav-tab <?php echo $action === 'list' ? 'nav-tab-active' : ''; ?>">
                All Reviews
            </a>
            <a href="?page=customer-reviews&action=add" class="nav-tab <?php echo $action === 'add' ? 'nav-tab-active' : ''; ?>">
                + Add Review
            </a>
            <a href="?page=customer-reviews&action=settings" class="nav-tab <?php echo $action === 'settings' ? 'nav-tab-active' : ''; ?>">
                Settings
            </a>
        </div>
        
        <?php
        if ($action === 'list') {
            cr_admin_reviews_list();
        } elseif ($action === 'add') {
            cr_admin_add_review_page();
        } elseif ($action === 'edit' && $review_id) {
            cr_admin_edit_review_page($review_id);
        } elseif ($action === 'settings') {
            cr_admin_settings_page();
        }
        ?>
    </div>
    <?php
}

function cr_admin_reviews_list() {
    global $wpdb;
    
    $table_name = $wpdb->prefix . 'customer_reviews';
    
    // Get all reviews
    $pending_reviews = $wpdb->get_results("SELECT * FROM $table_name WHERE status = 'pending' ORDER BY created_at DESC");
    $approved_reviews = $wpdb->get_results("SELECT * FROM $table_name WHERE status = 'approved' ORDER BY created_at DESC");
    $rejected_reviews = $wpdb->get_results("SELECT * FROM $table_name WHERE status = 'rejected' ORDER BY created_at DESC");
    
    ?>
    <!-- Nonce field for bulk actions -->
    <?php wp_nonce_field('cr_bulk_actions_nonce', 'cr_bulk_nonce'); ?>
    
    <div class="cr-reviews-admin">
        <h2>⏳ Pending Reviews (<?php echo count($pending_reviews); ?>)</h2>
        
        <?php if (!empty($pending_reviews)): ?>
            <!-- Bulk Actions -->
            <div class="cr-bulk-actions">
                <div class="cr-bulk-left">
                    <label class="cr-select-all">
                        <input type="checkbox" class="cr-select-all-pending" id="select-all-pending">
                        <span>Select All Pending</span>
                    </label>
                </div>
                <div class="cr-bulk-right">
                    <button class="button button-primary" id="approve-all-pending" style="display: none;">✓ Approve All</button>
                    <button class="button button-secondary" id="reject-all-pending" style="display: none;">✗ Reject All</button>
                    <button class="button button-danger" id="delete-all-pending" style="display: none;">🗑️ Delete All</button>
                </div>
            </div>
            
            <table class="wp-list-table widefat striped">
                <thead>
                    <tr>
                        <th width="5%"></th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Review</th>
                        <th>Rating</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pending_reviews as $review): ?>
                        <tr class="cr-review-row" data-id="<?php echo intval($review->id); ?>">
                            <td>
                                <input type="checkbox" class="cr-review-checkbox cr-pending-checkbox" data-id="<?php echo intval($review->id); ?>">
                            </td>
                            <td>
                                <?php echo esc_html($review->name); ?>
                                <?php if ($review->is_anonymous === 'yes'): ?>
                                    <br><span style="color: #999; font-size: 0.85em;">(Anonymous)</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo esc_html($review->email); ?></td>
                            <td>
                                <?php echo wp_kses_post(substr($review->text, 0, 100)); ?>
                                <?php if (strlen($review->text) > 100): ?>...<?php endif; ?>
                            </td>
                            <td>
                                <strong style="color: #fbbf24;">
                                    <?php echo esc_html($review->rating); ?>/5 ⭐
                                </strong>
                            </td>
                            <td><?php echo esc_html(date_i18n('M j, Y', strtotime($review->created_at))); ?></td>
                            <td style="white-space: nowrap;">
                                <a href="?page=customer-reviews&action=edit&id=<?php echo intval($review->id); ?>" class="button button-small">✏️ Edit</a>
                                <a href="?page=customer-reviews&status_action=approve&id=<?php echo intval($review->id); ?>" class="button button-success button-small">✓ Approve</a>
                                <a href="?page=customer-reviews&status_action=reject&id=<?php echo intval($review->id); ?>" class="button button-secondary button-small">✗ Reject</a>
                                <a href="?page=customer-reviews&status_action=delete&id=<?php echo intval($review->id); ?>" class="button button-danger button-small" onclick="return confirm('Are you sure you want to delete this review?')">🗑️ Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p style="padding: 20px; background: #f0fbfe; border-radius: 5px; color: #06b6d4;">No pending reviews waiting for approval.</p>
        <?php endif; ?>
        
        <hr style="margin: 40px 0;">
        
        <h2>✅ Approved Reviews (<?php echo count($approved_reviews); ?>)</h2>
        
        <?php if (!empty($approved_reviews)): ?>
            <!-- Bulk Actions for Approved -->
            <div class="cr-bulk-actions">
                <div class="cr-bulk-left">
                    <label class="cr-select-all">
                        <input type="checkbox" class="cr-select-all-approved" id="select-all-approved">
                        <span>Select All Approved</span>
                    </label>
                </div>
                <div class="cr-bulk-right">
                    <button class="button button-danger" id="delete-all-approved" style="display: none;">🗑️ Delete All</button>
                </div>
            </div>
            
            <table class="wp-list-table widefat striped">
                <thead>
                    <tr>
                        <th width="5%"></th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Review</th>
                        <th>Rating</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($approved_reviews as $review): ?>
                        <tr class="cr-review-row" data-id="<?php echo intval($review->id); ?>" style="background-color: #f0fbfe;">
                            <td>
                                <input type="checkbox" class="cr-review-checkbox cr-approved-checkbox" data-id="<?php echo intval($review->id); ?>">
                            </td>
                            <td>
                                <?php echo esc_html($review->name); ?>
                                <?php if ($review->is_anonymous === 'yes'): ?>
                                    <br><span style="color: #999; font-size: 0.85em;">(Anonymous)</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo esc_html($review->email); ?></td>
                            <td>
                                <?php echo wp_kses_post(substr($review->text, 0, 100)); ?>
                                <?php if (strlen($review->text) > 100): ?>...<?php endif; ?>
                            </td>
                            <td>
                                <strong style="color: #fbbf24;">
                                    <?php echo esc_html($review->rating); ?>/5 ⭐
                                </strong>
                            </td>
                            <td><?php echo esc_html(date_i18n('M j, Y', strtotime($review->created_at))); ?></td>
                            <td style="white-space: nowrap;">
                                <a href="?page=customer-reviews&action=edit&id=<?php echo intval($review->id); ?>" class="button button-small">✏️ Edit</a>
                                <a href="?page=customer-reviews&status_action=delete&id=<?php echo intval($review->id); ?>" class="button button-danger button-small" onclick="return confirm('Are you sure you want to delete this review?')">🗑️ Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p style="padding: 20px; background: #f0fbfe; border-radius: 5px; color: #06b6d4;">No approved reviews yet.</p>
        <?php endif; ?>
        
        <?php if (!empty($rejected_reviews)): ?>
            <hr style="margin: 40px 0;">
            
            <h2>❌ Rejected Reviews (<?php echo count($rejected_reviews); ?>)</h2>
            
            <table class="wp-list-table widefat striped">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Review</th>
                        <th>Rating</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rejected_reviews as $review): ?>
                        <tr style="background-color: #fef2f2; opacity: 0.7;">
                            <td>
                                <?php echo esc_html($review->name); ?>
                                <?php if ($review->is_anonymous === 'yes'): ?>
                                    <br><span style="color: #999; font-size: 0.85em;">(Anonymous)</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo esc_html($review->email); ?></td>
                            <td>
                                <?php echo wp_kses_post(substr($review->text, 0, 100)); ?>
                                <?php if (strlen($review->text) > 100): ?>...<?php endif; ?>
                            </td>
                            <td>
                                <strong style="color: #fbbf24;">
                                    <?php echo esc_html($review->rating); ?>/5 ⭐
                                </strong>
                            </td>
                            <td><?php echo esc_html(date_i18n('M j, Y', strtotime($review->created_at))); ?></td>
                            <td style="white-space: nowrap;">
                                <a href="?page=customer-reviews&action=edit&id=<?php echo intval($review->id); ?>" class="button button-small">✏️ Edit</a>
                                <a href="?page=customer-reviews&status_action=delete&id=<?php echo intval($review->id); ?>" class="button button-danger button-small" onclick="return confirm('Are you sure you want to delete this review?')">🗑️ Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <?php
}

function cr_admin_edit_review_page($review_id) {
    $review = cr_get_review_by_id($review_id);
    
    if (!$review) {
        echo '<div class="error"><p>Review not found.</p></div>';
        return;
    }
    
    $image_url = '';
    if ($review->image_id) {
        $image_data = wp_get_attachment_image_src($review->image_id, 'medium');
        $image_url = $image_data[0];
    }
    
    ?>
    <div class="cr-admin-form">
        <h2>Edit Review - <?php echo esc_html($review->name); ?></h2>
        
        <form method="post" class="cr-form" style="max-width: 800px;">
            <?php wp_nonce_field('cr_edit_nonce', 'cr_nonce'); ?>
            <input type="hidden" name="action" value="save_review">
            <input type="hidden" name="review_id" value="<?php echo intval($review->id); ?>">
            
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="name"><strong>Name</strong></label></th>
                    <td>
                        <input type="text" id="name" name="name" value="<?php echo esc_attr($review->name); ?>" class="regular-text" required>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="email"><strong>Email</strong></label></th>
                    <td>
                        <input type="email" id="email" name="email" value="<?php echo esc_attr($review->email); ?>" class="regular-text" required>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="rating"><strong>Rating</strong></label></th>
                    <td>
                        <select id="rating" name="rating" required>
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <option value="<?php echo $i; ?>" <?php selected($review->rating, $i); ?>><?php echo str_repeat('⭐', $i); ?> <?php echo $i; ?> Stars</option>
                            <?php endfor; ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="text"><strong>Review Text</strong></label></th>
                    <td>
                        <textarea id="text" name="text" class="large-text" rows="6" required><?php echo esc_textarea($review->text); ?></textarea>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="video_url"><strong>Video URL</strong></label></th>
                    <td>
                        <input type="url" id="video_url" name="video_url" value="<?php echo esc_attr($review->video_url); ?>" class="large-text" placeholder="https://youtube.com/watch?v=... or https://vimeo.com/...">
                        <p class="description">YouTube, Vimeo, or other video URL (optional)</p>
                        <?php if ($review->video_url): ?>
                            <p style="color: #06b6d4;"><strong>📹 Current Video:</strong> <a href="<?php echo esc_url($review->video_url); ?>" target="_blank"><?php echo esc_html($review->video_url); ?></a></p>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label><strong>Current Image</strong></label></th>
                    <td>
                        <?php if ($image_url): ?>
                            <div style="margin-bottom: 15px;">
                                <img src="<?php echo esc_url($image_url); ?>" style="max-width: 300px; max-height: 300px; border-radius: 8px;">
                                <p><small style="color: #999;">Review ID: <?php echo intval($review->id); ?></small></p>
                            </div>
                        <?php else: ?>
                            <p style="color: #999;">No image attached</p>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="status"><strong>Status</strong></label></th>
                    <td>
                        <select id="status" name="status" required>
                            <option value="pending" <?php selected($review->status, 'pending'); ?>>⏳ Pending</option>
                            <option value="approved" <?php selected($review->status, 'approved'); ?>>✅ Approved</option>
                            <option value="rejected" <?php selected($review->status, 'rejected'); ?>>❌ Rejected</option>
                        </select>
                    </td>
                </tr>
            </table>
            
            <p class="submit">
                <button type="submit" class="button button-primary button-large">💾 Save Changes</button>
                <a href="?page=customer-reviews" class="button button-large">← Back to Reviews</a>
            </p>
        </form>
    </div>
    <?php
}

function cr_admin_add_review_page() {
    ?>
    <div class="cr-admin-form">
        <h2>Add New Customer Review</h2>
        
        <form method="post" class="cr-form" style="max-width: 800px;">
            <?php wp_nonce_field('cr_edit_nonce', 'cr_nonce'); ?>
            <input type="hidden" name="action" value="save_review">
            <input type="hidden" name="review_id" value="0">
            
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="name"><strong>Name *</strong></label></th>
                    <td>
                        <input type="text" id="name" name="name" class="regular-text" placeholder="Customer name" required>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="email"><strong>Email *</strong></label></th>
                    <td>
                        <input type="email" id="email" name="email" class="regular-text" placeholder="customer@example.com" required>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="rating"><strong>Rating *</strong></label></th>
                    <td>
                        <select id="rating" name="rating" required>
                            <option value="">-- Select Rating --</option>
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <option value="<?php echo $i; ?>"><?php echo str_repeat('⭐', $i); ?> <?php echo $i; ?> Stars</option>
                            <?php endfor; ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="text"><strong>Review Text *</strong></label></th>
                    <td>
                        <textarea id="text" name="text" class="large-text" rows="6" placeholder="Write the customer review here..." required></textarea>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="video_url"><strong>Video URL (Optional)</strong></label></th>
                    <td>
                        <input type="url" id="video_url" name="video_url" class="large-text" placeholder="https://youtube.com/watch?v=... or https://vimeo.com/...">
                        <p class="description">YouTube, Vimeo, or other video URL</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="image_upload"><strong>Upload Image (Optional)</strong></label></th>
                    <td>
                        <input type="file" id="image_upload" name="image_upload" accept="image/jpeg,image/png,image/gif,image/webp">
                        <p class="description">Upload a JPG, PNG, GIF, or WebP image (optional)</p>
                        <div id="image_preview_admin" style="margin-top: 10px; display: none;">
                            <img id="image_preview_img_admin" src="" style="max-width: 200px; max-height: 200px; border-radius: 5px;">
                        </div>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="status"><strong>Status *</strong></label></th>
                    <td>
                        <select id="status" name="status" required>
                            <option value="pending">⏳ Pending (needs approval)</option>
                            <option value="approved" selected>✅ Approved (publish immediately)</option>
                            <option value="rejected">❌ Rejected</option>
                        </select>
                    </td>
                </tr>
            </table>
            
            <p class="submit">
                <button type="submit" class="button button-primary button-large">➕ Add Review</button>
                <a href="?page=customer-reviews" class="button button-large">← Cancel</a>
            </p>
        </form>
    </div>
    <?php
}

function cr_admin_settings_page() {
    ?>
    <div class="cr-settings" style="max-width: 900px;">
        <h2>Plugin Settings & Documentation</h2>
        
        <div style="background: #f0fbfe; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #06b6d4;">
            <h3 style="color: #06b6d4; margin-top: 0;">📌 How to Display Reviews</h3>
            <p>Use this shortcode on any page or post to display the reviews carousel:</p>
            <pre style="background: white; padding: 15px; border-radius: 5px; overflow-x: auto;"><code>[customer_reviews]</code></pre>
        </div>
        
        <h3>Shortcode Attributes:</h3>
        <table class="wp-list-table widefat striped" style="margin: 20px 0;">
            <thead>
                <tr>
                    <th>Attribute</th>
                    <th>Description</th>
                    <th>Example</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><code>limit</code></td>
                    <td>Maximum number of reviews to display</td>
                    <td><code>[customer_reviews limit="10"]</code></td>
                </tr>
                <tr>
                    <td><code>columns</code></td>
                    <td>Number of columns (1 or 2)</td>
                    <td><code>[customer_reviews columns="2"]</code></td>
                </tr>
            </tbody>
        </table>
        
        <h3>Example Usage:</h3>
        <pre style="background: #f3f4f6; padding: 15px; border-radius: 5px; overflow-x: auto;"><code>[customer_reviews limit="10" columns="2"]</code></pre>
        
        <h2>✨ Features</h2>
        <ul style="font-size: 16px; line-height: 1.8;">
            <li>✅ <strong>Image Upload</strong> - Customers can upload photos with reviews</li>
            <li>✅ <strong>Video Support</strong> - Add YouTube, Vimeo, or other video URLs</li>
            <li>✅ <strong>Anonymous Reviews</strong> - Customers can post as "Anonymous"</li>
            <li>✅ <strong>Star Ratings</strong> - 1-5 star rating system</li>
            <li>✅ <strong>Review Moderation</strong> - Approve/Reject pending reviews</li>
            <li>✅ <strong>Edit Reviews</strong> - Edit customer reviews from admin</li>
            <li>✅ <strong>Add Reviews</strong> - Manually add reviews from admin</li>
            <li>✅ <strong>Beautiful Design</strong> - Responsive carousel display</li>
            <li>✅ <strong>Secure</strong> - CSRF protection and input sanitization</li>
        </ul>
        
        <h2>Admin Capabilities</h2>
        <p>Shop managers and admins can:</p>
        <ul style="font-size: 16px; line-height: 1.8;">
            <li>📋 View all reviews (Pending, Approved, Rejected)</li>
            <li>✏️ Edit review details (name, email, text, rating, video)</li>
            <li>➕ Add new reviews manually</li>
            <li>✅ Approve pending customer reviews</li>
            <li>❌ Reject reviews</li>
            <li>🗑️ Delete reviews</li>
        </ul>
        
        <h2>Frontend Features</h2>
        <p>Customers can:</p>
        <ul style="font-size: 16px; line-height: 1.8;">
            <li>➕ Click "Share Your Love" button to write a review</li>
            <li>✍️ Add their name, email, rating, and review text</li>
            <li>📸 Upload photos/images</li>
            <li>🎬 Add video URLs (optional)</li>
            <li>😎 Post anonymously if they prefer</li>
            <li>🎠 Browse reviews with carousel navigation</li>
        </ul>
        
        <hr style="margin: 40px 0;">
        
        <div style="background: #f0fbfe; padding: 20px; border-radius: 8px; border-left: 4px solid #06b6d4;">
            <h3 style="color: #06b6d4; margin-top: 0;">🎨 Customization</h3>
            <p>The plugin comes with a beautiful pre-designed theme. All styles can be customized via:</p>
            <ul>
                <li>Theme customizer</li>
                <li>Custom CSS (add to your theme's style.css)</li>
                <li>WordPress page builder integrations</li>
            </ul>
        </div>
    </div>
    <?php
}
