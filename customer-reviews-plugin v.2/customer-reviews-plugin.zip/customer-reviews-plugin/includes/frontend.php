<?php

if (!defined('ABSPATH')) {
    exit;
}

// AJAX handler to load reviews
add_action('wp_ajax_load_reviews', 'cr_ajax_load_reviews');
add_action('wp_ajax_nopriv_load_reviews', 'cr_ajax_load_reviews');

function cr_ajax_load_reviews() {
    // Check nonce if it exists, otherwise allow for public
    if (isset($_POST['nonce']) && !wp_verify_nonce($_POST['nonce'], 'cr_nonce')) {
        wp_send_json_error('Security check failed');
        return;
    }
    
    $limit = isset($_POST['limit']) ? intval($_POST['limit']) : -1;
    
    $reviews = cr_get_reviews('approved', $limit);
    
    if (empty($reviews)) {
        wp_send_json_success(array(
            'html' => '<div class="cr-no-reviews-content"><p>No reviews yet. Be the first to share your experience!</p></div>',
            'count' => 0
        ));
        return;
    }
    
    $html = '';
    foreach ($reviews as $review) {
        $image_url = '';
        if ($review->image_id) {
            $image_data = wp_get_attachment_image_src($review->image_id, 'large');
            if ($image_data) {
                $image_url = $image_data[0];
            }
        }
        
        // Mask name and email if anonymous
        $display_name = $review->name;
        $display_email = $review->email;
        
        if ($review->is_anonymous === 'yes') {
            // Mask the name: first letter + asterisks + last letter
            if (strlen($review->name) > 2) {
                $display_name = $review->name[0] . str_repeat('*', strlen($review->name) - 2) . substr($review->name, -1);
            } else {
                $display_name = str_repeat('*', strlen($review->name));
            }
            
            // Mask the email: first letter + asterisks + @domain
            $email_parts = explode('@', $review->email);
            if (count($email_parts) === 2) {
                $local = $email_parts[0];
                $domain = $email_parts[1];
                $display_email = $local[0] . str_repeat('*', strlen($local) - 1) . '@' . $domain;
            }
        }
        
        $html .= '<div class="cr-review-card" data-review-id="' . intval($review->id) . '">
            <div class="cr-review-card-inner">
                <!-- LEFT SIDE: Text Content -->
                <div class="cr-review-left">
                    <div class="cr-review-text-section">
                        <p class="cr-review-text" data-full-text="' . esc_attr($review->text) . '">' . wp_kses_post($review->text) . '</p>
                        
                        <div class="cr-review-rating">';
        
        for ($i = 0; $i < $review->rating; $i++) {
            $html .= '<svg width="16" height="16" fill="#fbbf24" viewBox="0 0 24 24">
                        <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/>
                    </svg>';
        }
        
        $html .= '</div>
                    </div>
                    
                    <!-- Cloud Icon and User Info at Bottom -->
                    <div class="cr-review-footer">
                        <svg class="cr-cloud-icon" width="20" height="20" fill="#67e8f9" viewBox="0 0 24 24">
                            <path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96z"/>
                        </svg>
                        <div class="cr-user-info">
                            <p class="cr-review-name">' . esc_html($display_name) . '</p>
                            <p class="cr-review-email">' . esc_html($display_email) . '</p>
                        </div>
                    </div>
                </div>
                
                <!-- RIGHT SIDE: Image/Video -->
                <div class="cr-review-right">';
        
        if (!empty($review->video_url)) {
            $embedded_video = wp_oembed_get($review->video_url);
            if ($embedded_video) {
                $html .= '<div class="cr-review-video">' . $embedded_video . '</div>';
            }
        } elseif ($image_url) {
            $html .= '<img src="' . esc_url($image_url) . '" alt="' . esc_attr($display_name) . '" class="cr-review-image">';
        } else {
            $html .= '<div class="cr-review-image-placeholder"><span>' . esc_html(substr($display_name, 0, 1)) . '</span></div>';
        }
        
        $html .= '</div>
            </div>
        </div>';
    }
    
    wp_send_json_success(array(
        'html' => $html,
        'count' => count($reviews)
    ));
}

function cr_render_reviews_carousel($atts) {
    $atts = shortcode_atts(array(
        'limit' => -1,
        'columns' => 2
    ), $atts, 'customer_reviews');
    
    ob_start();
    ?>
    
    <div class="cr-carousel-wrapper">
        <div class="cr-carousel-header">
            <h2>Customer Love</h2>
            <p>Real stories from happy customers</p>
        </div>
        
        <div class="cr-carousel-container">
            <div class="cr-carousel-nav">
                <button class="cr-carousel-btn cr-carousel-btn-prev" data-carousel="reviews-carousel" aria-label="Previous reviews">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="15 18 9 12 15 6"></polyline>
                    </svg>
                </button>
            </div>
            
            <div class="cr-carousel-slides" id="reviews-carousel" data-limit="<?php echo intval($atts['limit']); ?>">
                <div class="cr-loading-spinner">
                    <div class="spinner"></div>
                    <p>Loading reviews...</p>
                </div>
            </div>
            
            <div class="cr-carousel-nav">
                <button class="cr-carousel-btn cr-carousel-btn-next" data-carousel="reviews-carousel" aria-label="Next reviews">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="9 18 15 12 9 6"></polyline>
                    </svg>
                </button>
            </div>
        </div>
        
        <div class="cr-add-review-section">
            <button class="cr-add-review-btn" id="cr-toggle-form" aria-label="Add a review">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="12" y1="5" x2="12" y2="19"></line>
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                </svg>
                Share Your Love
            </button>
        </div>
        
        <!-- Review Form Modal -->
        <div class="cr-form-modal" id="cr-form-modal" role="dialog" aria-labelledby="cr-form-title" aria-hidden="true">
            <div class="cr-form-modal-content">
                <div class="cr-form-header">
                    <h3 id="cr-form-title">Write Your Review</h3>
                    <button class="cr-form-close" id="cr-close-form" aria-label="Close">&times;</button>
                </div>
                
                <form id="cr-review-form" class="cr-review-form" enctype="multipart/form-data">
                    <?php wp_nonce_field('cr_nonce', 'nonce'); ?>
                    
                    <div class="cr-form-group">
                        <label for="cr-name">Your Name *</label>
                        <input type="text" id="cr-name" name="name" placeholder="Enter your name (or leave blank for anonymous)">
                    </div>
                    
                    <div class="cr-form-group">
                        <label for="cr-email">Your Email *</label>
                        <input type="email" id="cr-email" name="email" placeholder="your@email.com (or leave blank for anonymous)">
                    </div>
                    
                    <div class="cr-form-group">
                        <label class="cr-checkbox-label">
                            <input type="checkbox" id="cr-anonymous" name="is_anonymous" value="yes">
                            <span>Post as Anonymous (e.g., "m**k")</span>
                        </label>
                        <p class="cr-help-text">Your name will be masked and email won't be displayed if you check this</p>
                    </div>
                    
                    <div class="cr-form-group">
                        <label>Rating *</label>
                        <div class="cr-rating-input">
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <input type="radio" id="cr-rating-<?php echo $i; ?>" name="rating" value="<?php echo $i; ?>" <?php echo $i === 5 ? 'checked' : ''; ?> required>
                                <label for="cr-rating-<?php echo $i; ?>">
                                    <svg width="28" height="28" fill="currentColor" viewBox="0 0 24 24">
                                        <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/>
                                    </svg>
                                </label>
                            <?php endfor; ?>
                        </div>
                    </div>
                    
                    <div class="cr-form-group">
                        <label for="cr-text">Your Review *</label>
                        <textarea id="cr-text" name="text" rows="4" placeholder="Share your experience..." required></textarea>
                    </div>
                    
                    <div class="cr-form-group">
                        <label>Add Media (Optional)</label>
                        <div class="cr-form-tabs">
                            <button type="button" class="cr-tab-btn active" data-tab="photo-tab">📸 Photo</button>
                            <button type="button" class="cr-tab-btn" data-tab="video-tab">🎬 Video</button>
                        </div>
                        
                        <!-- Photo Upload Tab -->
                        <div id="photo-tab" class="cr-tab-content active">
                            <div class="cr-image-upload">
                                <label for="cr-image" class="cr-image-label">
                                    <input type="file" id="cr-image" name="image" accept="image/jpeg,image/png,image/gif,image/webp" style="display: none;">
                                    <div class="cr-image-preview-area" id="cr-image-preview-area">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                                            <polyline points="17 8 12 3 7 8"></polyline>
                                            <line x1="12" y1="3" x2="12" y2="15"></line>
                                        </svg>
                                        <span>Click to Upload Photo</span>
                                    </div>
                                </label>
                                <div class="cr-image-preview" id="cr-image-preview" style="display: none;">
                                    <img id="cr-preview-img" src="" alt="Preview">
                                    <button type="button" class="cr-remove-image" id="cr-remove-image">&times;</button>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Video URL Tab -->
                        <div id="video-tab" class="cr-tab-content">
                            <input type="url" id="cr-video-url" name="video_url" placeholder="https://youtube.com/watch?v=... or https://vimeo.com/..." class="cr-video-input">
                            <p class="cr-help-text">Paste YouTube, Vimeo, or other video URL</p>
                        </div>
                    </div>
                    
                    <div class="cr-form-actions">
                        <button type="submit" class="cr-btn cr-btn-primary">Post Review</button>
                        <button type="button" class="cr-btn cr-btn-secondary" id="cr-cancel-form">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Review Details Modal -->
        <div class="cr-review-details-modal" id="cr-review-details-modal" role="dialog" aria-labelledby="review-details-title" aria-hidden="true">
            <div class="cr-review-details-content">
                <div class="cr-review-details-header">
                    <h2 id="review-details-title">Review Details</h2>
                    <button class="cr-review-details-close" id="cr-close-review-details" aria-label="Close">&times;</button>
                </div>
                
                <div class="cr-review-details-body">
                    <!-- Review Info -->
                    <div class="cr-review-details-info">
                        <div class="cr-review-details-item">
                            <label>Reviewer</label>
                            <value id="review-details-name"></value>
                        </div>
                        <div class="cr-review-details-item">
                            <label>Email</label>
                            <value id="review-details-email"></value>
                        </div>
                    </div>
                    
                    <div class="cr-review-details-info">
                        <div class="cr-review-details-item">
                            <label>Rating</label>
                            <div class="cr-review-details-stars" id="review-details-stars"></div>
                        </div>
                        <div class="cr-review-details-item">
                            <label>Date</label>
                            <value id="review-details-date"></value>
                        </div>
                    </div>
                    
                    <!-- Media -->
                    <div class="cr-review-details-media" id="review-details-media-container" style="display: none;">
                        <div class="cr-review-details-media-title">Media</div>
                        <div id="review-details-media"></div>
                    </div>
                    
                    <!-- Full Text -->
                    <div class="cr-review-details-full-text">
                        <label>Full Review</label>
                        <div class="cr-review-details-text-content" id="review-details-text"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Load reviews on page load
        crLoadReviews();
    });
    </script>
    
    <?php
    return ob_get_clean();
}
