# Customer Love Reviews - WordPress Plugin

A beautiful, modern WordPress plugin for displaying customer reviews with image uploads and a stunning carousel interface.

## Features

- ✨ Beautiful, modern design matching the "Love, Mommies & Daddies" aesthetic
- 📸 Image upload support for customer reviews
- ⭐ Star rating system (1-5 stars)
- 🎠 Responsive carousel display
- 📋 Admin dashboard for managing reviews
- ✅ Review moderation (approve/reject/delete)
- 📱 Fully responsive design
- 🎨 Soft cyan/turquoise color scheme
- 🔒 Secure AJAX submission with nonce verification

## Installation

1. Extract the `customer-reviews-plugin` folder to your WordPress plugins directory: `/wp-content/plugins/`
2. Activate the plugin through the WordPress admin dashboard
3. The plugin will automatically create the necessary database tables

## Usage

Add the reviews carousel to any page or post using the shortcode:

```
[customer_reviews]
```

### Shortcode Attributes

- `limit="10"` - Limit the number of reviews displayed (default: all approved reviews)
- `columns="2"` - Number of carousel columns (1 or 2, default: 2)

### Examples

Display all approved reviews in 2-column layout:
```
[customer_reviews]
```

Display only 5 most recent reviews in single column:
```
[customer_reviews limit="5" columns="1"]
```

## Admin Panel

1. Go to **Customer Reviews** in the WordPress admin menu
2. View all reviews and their status (Pending, Approved, Rejected)
3. Approve, reject, or delete reviews
4. View the shortcode usage instructions in the Settings tab

## Plugin Structure

```
customer-reviews-plugin/
├── customer-reviews.php          # Main plugin file
├── includes/
│   ├── database.php              # Database functions
│   ├── admin.php                 # Admin panel
│   └── frontend.php              # Frontend display
├── assets/
│   ├── css/
│   │   ├── frontend.css          # Frontend styles
│   │   └── admin.css             # Admin styles
│   └── js/
│       ├── frontend.js           # Frontend functionality
│       └── admin.js              # Admin functionality
└── README.md                     # This file
```

## Database

The plugin creates a custom table to store reviews:

- `name` - Customer name
- `email` - Customer email
- `text` - Review text
- `rating` - Star rating (1-5)
- `image_id` - WordPress media attachment ID
- `status` - Review status (pending, approved, rejected)
- `created_at` - Review submission date

## Security

- CSRF protection using WordPress nonces
- Input sanitization for all form fields
- File upload validation
- Proper capability checks for admin functions
- Secure AJAX endpoints

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers

## Version

1.0.0

## License

GPL v2 or later

## Support

For issues or feature requests, please contact the plugin author.

## Credits

Designed with inspiration from modern testimonial designs and best practices in web design.
