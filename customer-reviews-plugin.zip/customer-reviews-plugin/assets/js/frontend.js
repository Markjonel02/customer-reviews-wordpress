// Global function to load reviews
function crLoadReviews() {
    const carousel = document.getElementById('reviews-carousel');
    if (!carousel) return;

    const limit = carousel.getAttribute('data-limit') || '-1';
    
    const formData = new FormData();
    formData.append('action', 'load_reviews');
    formData.append('limit', limit);
    
    // Add nonce if available
    if (typeof crData !== 'undefined' && crData.nonce) {
        formData.append('nonce', crData.nonce);
    }

    fetch(crData.ajaxurl, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            carousel.innerHTML = data.data.html;
            initCarousel('reviews-carousel');
        } else {
            console.error('Error loading reviews:', data.data);
            carousel.innerHTML = '<div class="cr-no-reviews-content"><p>Error loading reviews. Please refresh the page.</p></div>';
        }
    })
    .catch(error => {
        console.error('Fetch error:', error);
        carousel.innerHTML = '<div class="cr-no-reviews-content"><p>Error loading reviews.</p></div>';
    });
}

// Show popup notification
function showPopup(message, type = 'success', duration = 5000) {
    const popup = document.createElement('div');
    popup.className = `cr-popup ${type}`;
    
    let icon = '✓';
    if (type === 'error') icon = '✕';
    if (type === 'info') icon = 'ℹ';
    
    popup.innerHTML = `
        <div class="cr-popup-content">
            <div class="cr-popup-icon">${icon}</div>
            <p class="cr-popup-text">${message}</p>
        </div>
    `;
    
    document.body.appendChild(popup);
    
    setTimeout(() => {
        popup.classList.add('remove');
        setTimeout(() => popup.remove(), 300);
    }, duration);
}

// Carousel functionality
const carousels = {};

function initCarousel(carouselId) {
    const carousel = document.getElementById(carouselId);
    if (!carousel) return;

    const slides = carousel.querySelectorAll('.cr-review-card');
    const totalSlides = slides.length;
    
    if (totalSlides === 0) return;

    carousels[carouselId] = {
        currentIndex: 0,
        totalSlides: totalSlides
    };

    updateCarousel(carouselId);
}

function updateCarousel(carouselId) {
    const carousel = document.getElementById(carouselId);
    if (!carousel) return;

    const slides = carousel.querySelectorAll('.cr-review-card');
    const state = carousels[carouselId];
    const visibleCount = window.innerWidth < 768 ? 1 : 2;
    
    slides.forEach((slide, index) => {
        slide.style.display = (index >= state.currentIndex && index < state.currentIndex + visibleCount) ? 'flex' : 'none';
    });
}

function nextSlide(carouselId) {
    const state = carousels[carouselId];
    const carousel = document.getElementById(carouselId);
    if (!carousel) return;

    const slides = carousel.querySelectorAll('.cr-review-card');
    const visibleCount = window.innerWidth < 768 ? 1 : 2;
    const maxIndex = Math.max(0, slides.length - visibleCount);
    
    state.currentIndex = Math.min(state.currentIndex + 1, maxIndex);
    updateCarousel(carouselId);
}

function prevSlide(carouselId) {
    const state = carousels[carouselId];
    state.currentIndex = Math.max(state.currentIndex - 1, 0);
    updateCarousel(carouselId);
}

jQuery(document).ready(function($) {
    // Carousel button handlers
    $('.cr-carousel-btn-next').on('click', function() {
        const carouselId = $(this).data('carousel');
        nextSlide(carouselId);
    });

    $('.cr-carousel-btn-prev').on('click', function() {
        const carouselId = $(this).data('carousel');
        prevSlide(carouselId);
    });

    // Reinitialize carousel on window resize
    $(window).on('resize', function() {
        $('.cr-carousel-slides').each(function() {
            if (carousels[$(this).attr('id')]) {
                updateCarousel($(this).attr('id'));
            }
        });
    });

    // Tab switching
    $('.cr-tab-btn').on('click', function(e) {
        e.preventDefault();
        const tabName = $(this).data('tab');
        
        // Hide all tabs
        $('.cr-tab-content').removeClass('active').hide();
        $('.cr-tab-btn').removeClass('active');
        
        // Show selected tab
        $('#' + tabName).addClass('active').show();
        $(this).addClass('active');
    });

    // Modal handlers
    $('#cr-toggle-form').on('click', function() {
        $('#cr-form-modal').addClass('active').attr('aria-hidden', 'false');
        $('#cr-name').focus();
    });

    $('#cr-close-form, #cr-cancel-form').on('click', function(e) {
        if (e.target.id !== 'cr-cancel-form') e.preventDefault();
        $('#cr-form-modal').removeClass('active').attr('aria-hidden', 'true');
        $('#cr-review-form')[0].reset();
        resetImagePreview();
        $('.cr-tab-content').removeClass('active').hide();
        $('#photo-tab').addClass('active').show();
        $('.cr-tab-btn').removeClass('active');
        $('.cr-tab-btn').first().addClass('active');
    });

    // Close modal when clicking outside
    $('#cr-form-modal').on('click', function(e) {
        if ($(e.target).is('#cr-form-modal')) {
            $(this).removeClass('active').attr('aria-hidden', 'true');
            resetImagePreview();
        }
    });

    // Anonymous checkbox handler - keep fields visible, just mark as anonymous
    $('#cr-anonymous').on('change', function() {
        if ($(this).is(':checked')) {
            // Keep fields enabled and visible, they're just optional when anonymous
            $('#cr-name').removeAttr('required');
            $('#cr-email').removeAttr('required');
            // You can still fill them but they'll be masked when displayed
        } else {
            // Make required when not anonymous
            $('#cr-name').attr('required', true);
            $('#cr-email').attr('required', true);
        }
    });

    // Image upload handler
    $('#cr-image').on('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(event) {
                $('#cr-preview-img').attr('src', event.target.result);
                $('#cr-image-preview-area').hide();
                $('#cr-image-preview').show();
            };
            reader.readAsDataURL(file);
        }
    });

    // Remove image handler
    $('#cr-remove-image').on('click', function(e) {
        e.preventDefault();
        resetImagePreview();
    });

    function resetImagePreview() {
        $('#cr-image').val('');
        $('#cr-preview-img').attr('src', '');
        $('#cr-image-preview').hide();
        $('#cr-image-preview-area').show();
    }

    // Star rating interaction
    $('.cr-rating-input label').on('mouseenter', function() {
        const ratingValue = $(this).prev('input[type="radio"]').val();
        $('.cr-rating-input label').each(function(index) {
            if (index < ratingValue) {
                $(this).find('svg').css('color', '#fcd34d');
            } else {
                $(this).find('svg').css('color', '#cbd5e1');
            }
        });
    }).on('mouseleave', function() {
        const checkedValue = $('.cr-rating-input input[type="radio"]:checked').val() || 0;
        $('.cr-rating-input label').each(function(index) {
            if (index < checkedValue) {
                $(this).find('svg').css('color', '#fbbf24');
            } else {
                $(this).find('svg').css('color', '#cbd5e1');
            }
        });
    });

    // Form validation and submission
    $('#cr-review-form').on('submit', function(e) {
        e.preventDefault();

        // Check required fields
        const name = $('#cr-name').val().trim();
        const email = $('#cr-email').val().trim();
        const text = $('#cr-text').val().trim();
        const rating = $('input[name="rating"]:checked').val();
        const isAnonymous = $('#cr-anonymous').is(':checked');

        if (!isAnonymous && !name) {
            alert('Please enter your name or check "Post as Anonymous"');
            return;
        }

        if (!isAnonymous && !email) {
            alert('Please enter your email or check "Post as Anonymous"');
            return;
        }

        if (!text) {
            alert('Please write a review');
            return;
        }

        if (!rating) {
            alert('Please select a rating');
            return;
        }

        // Validate email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!isAnonymous && !emailRegex.test(email)) {
            alert('Please enter a valid email address');
            return;
        }

        // Create FormData properly to include files
        const formData = new FormData();
        
        // Add form fields
        formData.append('action', 'submit_review');
        formData.append('nonce', crData.nonce);
        formData.append('name', name);
        formData.append('email', email);
        formData.append('text', text);
        formData.append('rating', rating);
        formData.append('is_anonymous', isAnonymous ? 'yes' : 'no');
        formData.append('video_url', $('#cr-video-url').val() || '');
        
        // Add image file if selected
        const imageInput = document.getElementById('cr-image');
        if (imageInput && imageInput.files.length > 0) {
            formData.append('image', imageInput.files[0]);
        }

        // Show loading state
        const submitBtn = $(this).find('button[type="submit"]');
        const originalText = submitBtn.text();
        submitBtn.prop('disabled', true).text('Posting...');

        $.ajax({
            type: 'POST',
            url: crData.ajaxurl,
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    const message = response.data.message;
                    showPopup(message, 'success');
                    
                    // Close modal
                    $('#cr-form-modal').removeClass('active').attr('aria-hidden', 'true');
                    $('#cr-review-form')[0].reset();
                    resetImagePreview();
                    
                    // Reset rating display
                    $('.cr-rating-input input:nth-child(9)').prop('checked', true);
                    $('.cr-rating-input label').each(function(index) {
                        if (index < 5) {
                            $(this).find('svg').css('color', '#fbbf24');
                        } else {
                            $(this).find('svg').css('color', '#cbd5e1');
                        }
                    });
                    
                    // Reload reviews container
                    if (response.data.auto_approved) {
                        crLoadReviews();
                    } else {
                        setTimeout(function() {
                            crLoadReviews();
                        }, 1500);
                    }
                    
                    // Reset button
                    submitBtn.prop('disabled', false).text(originalText);
                } else {
                    let errorMsg = response.data || 'An error occurred while submitting your review. Please try again.';
                    if (typeof errorMsg === 'string' && errorMsg.length > 200) {
                        errorMsg = 'Failed to post review. Please check your information and try again.';
                    }
                    showPopup('Error: ' + errorMsg, 'error');
                    submitBtn.prop('disabled', false).text(originalText);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', error);
                let errorMsg = 'Network error. Please check your connection and try again.';
                showPopup('Error: ' + errorMsg, 'error');
                submitBtn.prop('disabled', false).text(originalText);
            }
        });
    });

    // Close modal on escape key
    $(document).on('keydown', function(e) {
        if (e.key === 'Escape' && $('#cr-form-modal').hasClass('active')) {
            $('#cr-form-modal').removeClass('active').attr('aria-hidden', 'true');
            resetImagePreview();
        }
        if (e.key === 'Escape' && $('#cr-review-details-modal').hasClass('active')) {
            $('#cr-review-details-modal').removeClass('active').attr('aria-hidden', 'true');
        }
    });

    // Review Details Modal
    $(document).on('click', '.cr-review-card', function(e) {
        // Don't open modal if clicking on image or video
        if ($(e.target).closest('.cr-review-image, .cr-review-video, .cr-review-image-placeholder').length) {
            return;
        }
        
        const reviewId = $(this).data('review-id');
        if (reviewId) {
            openReviewDetailsModal(reviewId, $(this));
        }
    });

    function openReviewDetailsModal(reviewId, cardElement) {
        // Extract data from card
        const name = cardElement.find('.cr-review-name').text().trim();
        const email = cardElement.find('.cr-review-email').text().trim();
        const text = cardElement.find('.cr-review-text').attr('data-full-text') || cardElement.find('.cr-review-text').text().trim();
        const rating = cardElement.find('.cr-review-rating svg').length;
        const date = cardElement.find('.cr-review-date').text().trim();
        const imageElement = cardElement.find('.cr-review-image');
        const videoElement = cardElement.find('.cr-review-video');

        // Populate modal
        $('#review-details-name').text(name);
        $('#review-details-email').text(email);
        $('#review-details-date').text(date);
        $('#review-details-text').text(text);

        // Add stars
        let starsHtml = '';
        for (let i = 0; i < rating; i++) {
            starsHtml += '<svg width="20" height="20" fill="#fbbf24" viewBox="0 0 24 24"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>';
        }
        $('#review-details-stars').html(starsHtml);

        // Add media
        const mediaContainer = $('#review-details-media-container');
        const mediaContent = $('#review-details-media');
        mediaContent.empty();
        
        if (imageElement.length) {
            mediaContent.html('<img src="' + imageElement.attr('src') + '" alt="Review image" class="cr-review-details-image">');
            mediaContainer.show();
        } else if (videoElement.length) {
            const videoHtml = videoElement.html();
            mediaContent.html('<div class="cr-review-details-video">' + videoHtml + '</div>');
            mediaContainer.show();
        } else {
            mediaContainer.hide();
        }

        // Show modal
        $('#cr-review-details-modal').addClass('active').attr('aria-hidden', 'false');
        $('body').css('overflow', 'hidden');
    }

    // Close review details modal
    $('#cr-close-review-details, #cr-review-details-modal').on('click', function(e) {
        if (e.target === this || $(e.target).closest('#cr-close-review-details').length) {
            $('#cr-review-details-modal').removeClass('active').attr('aria-hidden', 'true');
            $('body').css('overflow', 'auto');
        }
    });

    // Initialize first tab as active
    $('#photo-tab').addClass('active').show();
    $('.cr-tab-btn').first().addClass('active');
});
