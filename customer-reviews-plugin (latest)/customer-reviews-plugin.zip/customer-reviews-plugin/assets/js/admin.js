jQuery(document).ready(function($) {
    // Show admin popup
    function showAdminPopup(message, type = 'success', title = '') {
        const popup = document.createElement('div');
        popup.className = `cr-admin-popup ${type}`;
        
        let icon = '✓';
        if (type === 'error') icon = '✕';
        if (type === 'info') icon = 'ℹ';
        if (type === 'success') icon = '✓';
        
        let titleHtml = '';
        if (title) {
            titleHtml = `<div class="cr-admin-popup-header">
                <div class="cr-admin-popup-icon">${icon}</div>
                <h3 class="cr-admin-popup-title">${title}</h3>
            </div>`;
        }
        
        popup.innerHTML = `
            ${titleHtml}
            <p class="cr-admin-popup-message">${message}</p>
        `;
        
        document.body.appendChild(popup);
        
        setTimeout(() => {
            popup.classList.add('remove');
            setTimeout(() => popup.remove(), 300);
        }, 5000);
    }
    
    // Pending Reviews - Select All
    $('#select-all-pending').on('change', function() {
        const isChecked = $(this).is(':checked');
        $('.cr-pending-checkbox').prop('checked', isChecked);
        updatePendingButtons();
    });

    // Pending Reviews - Individual checkbox
    $(document).on('change', '.cr-pending-checkbox', function() {
        updatePendingButtons();
        const allChecked = $('.cr-pending-checkbox').length === $('.cr-pending-checkbox:checked').length;
        $('#select-all-pending').prop('checked', allChecked);
    });

    // Update Pending Buttons visibility
    function updatePendingButtons() {
        const checkedCount = $('.cr-pending-checkbox:checked').length;
        if (checkedCount > 0) {
            $('#approve-all-pending, #reject-all-pending, #delete-all-pending').show();
        } else {
            $('#approve-all-pending, #reject-all-pending, #delete-all-pending').hide();
        }
    }

    // Approve All Pending
    $('#approve-all-pending').on('click', function() {
        const ids = $('.cr-pending-checkbox:checked').map(function() {
            return $(this).data('id');
        }).get();
        
        if (ids.length === 0) return;
        
        if (confirm('Approve ' + ids.length + ' reviews?')) {
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'cr_bulk_approve',
                    ids: ids,
                    nonce: jQuery('#cr_bulk_nonce').val()
                },
                success: function(response) {
                    if (response.success) {
                        showAdminPopup('Reviews approved successfully!', 'success', 'Success');
                        setTimeout(() => location.reload(), 1500);
                    } else {
                        showAdminPopup(response.data || 'Error approving reviews', 'error', 'Error');
                    }
                },
                error: function() {
                    showAdminPopup('Network error. Please try again.', 'error', 'Error');
                }
            });
        }
    });

    // Reject All Pending
    $('#reject-all-pending').on('click', function() {
        const ids = $('.cr-pending-checkbox:checked').map(function() {
            return $(this).data('id');
        }).get();
        
        if (ids.length === 0) return;
        
        if (confirm('Reject ' + ids.length + ' reviews?')) {
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'cr_bulk_reject',
                    ids: ids,
                    nonce: jQuery('#cr_bulk_nonce').val()
                },
                success: function(response) {
                    if (response.success) {
                        showAdminPopup('Reviews rejected successfully!', 'success', 'Success');
                        setTimeout(() => location.reload(), 1500);
                    } else {
                        showAdminPopup(response.data || 'Error rejecting reviews', 'error', 'Error');
                    }
                },
                error: function() {
                    showAdminPopup('Network error. Please try again.', 'error', 'Error');
                }
            });
        }
    });

    // Delete All Pending
    $('#delete-all-pending').on('click', function() {
        const ids = $('.cr-pending-checkbox:checked').map(function() {
            return $(this).data('id');
        }).get();
        
        if (ids.length === 0) return;
        
        if (confirm('Delete ' + ids.length + ' reviews? This cannot be undone.')) {
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'cr_bulk_delete',
                    ids: ids,
                    nonce: jQuery('#cr_bulk_nonce').val()
                },
                success: function(response) {
                    if (response.success) {
                        showAdminPopup('Reviews deleted successfully!', 'success', 'Success');
                        setTimeout(() => location.reload(), 1500);
                    } else {
                        showAdminPopup(response.data || 'Error deleting reviews', 'error', 'Error');
                    }
                },
                error: function() {
                    showAdminPopup('Network error. Please try again.', 'error', 'Error');
                }
            });
        }
    });

    // Approved Reviews - Select All
    $('#select-all-approved').on('change', function() {
        const isChecked = $(this).is(':checked');
        $('.cr-approved-checkbox').prop('checked', isChecked);
        updateApprovedButtons();
    });

    // Approved Reviews - Individual checkbox
    $(document).on('change', '.cr-approved-checkbox', function() {
        updateApprovedButtons();
        const allChecked = $('.cr-approved-checkbox').length === $('.cr-approved-checkbox:checked').length;
        $('#select-all-approved').prop('checked', allChecked);
    });

    // Update Approved Buttons visibility
    function updateApprovedButtons() {
        const checkedCount = $('.cr-approved-checkbox:checked').length;
        if (checkedCount > 0) {
            $('#delete-all-approved').show();
        } else {
            $('#delete-all-approved').hide();
        }
    }

    // Delete All Approved
    $('#delete-all-approved').on('click', function() {
        const ids = $('.cr-approved-checkbox:checked').map(function() {
            return $(this).data('id');
        }).get();
        
        if (ids.length === 0) return;
        
        if (confirm('Delete ' + ids.length + ' approved reviews? This cannot be undone.')) {
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'cr_bulk_delete',
                    ids: ids,
                    nonce: jQuery('#cr_bulk_nonce').val()
                },
                success: function(response) {
                    if (response.success) {
                        showAdminPopup('Reviews deleted successfully!', 'success', 'Success');
                        setTimeout(() => location.reload(), 1500);
                    } else {
                        showAdminPopup(response.data || 'Error deleting reviews', 'error', 'Error');
                    }
                },
                error: function() {
                    showAdminPopup('Network error. Please try again.', 'error', 'Error');
                }
            });
        }
    });
});
