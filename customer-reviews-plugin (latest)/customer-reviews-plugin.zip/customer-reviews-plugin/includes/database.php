<?php

if (!defined('ABSPATH')) {
    exit;
}

function cr_mask_name($name) {
    if (strlen($name) <= 2) {
        return $name[0] . '***';
    }
    $first = $name[0];
    $last = $name[strlen($name) - 1];
    $middle = str_repeat('*', strlen($name) - 2);
    return $first . $middle . $last;
}

function cr_create_database_tables() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'customer_reviews';
    $charset_collate = $wpdb->get_charset_collate();
    
    // Use proper charset
    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT PRIMARY KEY,
        name varchar(255) NOT NULL DEFAULT '',
        email varchar(255) NOT NULL DEFAULT '',
        text longtext,
        rating mediumint(9),
        image_id mediumint(9),
        video_url varchar(500),
        is_anonymous varchar(10),
        status varchar(20),
        created_at datetime,
        updated_at datetime
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

function cr_repair_database_columns() {
    global $wpdb;
    $table = $wpdb->prefix . 'customer_reviews';
    
    // Get existing columns
    $columns = $wpdb->get_results("DESCRIBE $table");
    $existing_columns = array();
    foreach ($columns as $column) {
        $existing_columns[] = $column->Field;
    }
    
    // Add missing columns if they don't exist
    if (!in_array('video_url', $existing_columns)) {
        $wpdb->query("ALTER TABLE $table ADD COLUMN video_url VARCHAR(500)");
    }
    if (!in_array('is_anonymous', $existing_columns)) {
        $wpdb->query("ALTER TABLE $table ADD COLUMN is_anonymous VARCHAR(10)");
    }
    if (!in_array('image_id', $existing_columns)) {
        $wpdb->query("ALTER TABLE $table ADD COLUMN image_id MEDIUMINT(9)");
    }
    if (!in_array('updated_at', $existing_columns)) {
        $wpdb->query("ALTER TABLE $table ADD COLUMN updated_at DATETIME");
    }
}

function cr_add_review($data) {
    global $wpdb;
    $table = $wpdb->prefix . 'customer_reviews';
    
    // Sanitize and set defaults
    $name = !empty($data['name']) ? sanitize_text_field($data['name']) : 'Customer';
    $email = !empty($data['email']) ? sanitize_email($data['email']) : 'noemail@example.com';
    $text = !empty($data['text']) ? wp_kses_post($data['text']) : '';
    $rating = !empty($data['rating']) ? intval($data['rating']) : 5;
    $image_id = !empty($data['image_id']) ? intval($data['image_id']) : 0;
    $video_url = !empty($data['video_url']) ? esc_url_raw($data['video_url']) : '';
    $is_anonymous = !empty($data['is_anonymous']) ? sanitize_text_field($data['is_anonymous']) : 'no';
    $status = !empty($data['status']) ? sanitize_text_field($data['status']) : 'pending';
    
    if (empty($text)) {
        return false;
    }
    
    // Ensure table exists and repair columns
    if (!$wpdb->get_var("SHOW TABLES LIKE '$table'")) {
        cr_create_database_tables();
    } else {
        cr_repair_database_columns();
    }
    
    // Use direct query with proper escaping
    $query = $wpdb->prepare(
        "INSERT INTO $table (name, email, text, rating, image_id, video_url, is_anonymous, status, created_at, updated_at) 
         VALUES (%s, %s, %s, %d, %d, %s, %s, %s, %s, %s)",
        $name,
        $email,
        $text,
        $rating,
        $image_id,
        $video_url,
        $is_anonymous,
        $status,
        current_time('mysql'),
        current_time('mysql')
    );
    
    // Execute and check for errors
    $result = $wpdb->query($query);
    
    if ($result === false) {
        error_log('CR Database Insert Error: ' . $wpdb->last_error);
        error_log('CR Query: ' . $query);
        return false;
    }
    
    $insert_id = $wpdb->insert_id;
    
    if (!$insert_id) {
        error_log('CR Database Error: No insert ID returned');
        return false;
    }
    
    return $insert_id;
}

function cr_get_reviews($status = 'approved', $limit = -1) {
    global $wpdb;
    $table = $wpdb->prefix . 'customer_reviews';
    
    $query = $wpdb->prepare(
        "SELECT * FROM $table WHERE status = %s ORDER BY created_at DESC",
        $status
    );
    
    if ($limit > 0) {
        $query .= " LIMIT " . intval($limit);
    }
    
    return $wpdb->get_results($query);
}

function cr_update_review_status($review_id, $status) {
    global $wpdb;
    $table = $wpdb->prefix . 'customer_reviews';
    
    $query = $wpdb->prepare(
        "UPDATE $table SET status = %s WHERE id = %d",
        sanitize_text_field($status),
        intval($review_id)
    );
    
    return $wpdb->query($query);
}

function cr_delete_review($review_id) {
    global $wpdb;
    $table = $wpdb->prefix . 'customer_reviews';
    
    $query = $wpdb->prepare(
        "DELETE FROM $table WHERE id = %d",
        intval($review_id)
    );
    
    return $wpdb->query($query);
}

function cr_update_review($review_id, $data) {
    global $wpdb;
    $table = $wpdb->prefix . 'customer_reviews';
    
    $update_data = array();
    $format = array();
    
    if (!empty($data['name'])) {
        $update_data['name'] = sanitize_text_field($data['name']);
        $format[] = '%s';
    }
    if (!empty($data['email'])) {
        $update_data['email'] = sanitize_email($data['email']);
        $format[] = '%s';
    }
    if (!empty($data['text'])) {
        $update_data['text'] = wp_kses_post($data['text']);
        $format[] = '%s';
    }
    if (!empty($data['rating'])) {
        $update_data['rating'] = intval($data['rating']);
        $format[] = '%d';
    }
    if (!empty($data['status'])) {
        $update_data['status'] = sanitize_text_field($data['status']);
        $format[] = '%s';
    }
    if (!empty($data['video_url'])) {
        $update_data['video_url'] = esc_url_raw($data['video_url']);
        $format[] = '%s';
    }
    if (!empty($data['image_id'])) {
        $update_data['image_id'] = intval($data['image_id']);
        $format[] = '%d';
    }
    
    if (empty($update_data)) {
        return false;
    }
    
    $format[] = '%d';
    
    return $wpdb->update(
        $table,
        $update_data,
        array('id' => intval($review_id)),
        $format,
        array('%d')
    );
}

function cr_get_review_by_id($review_id) {
    global $wpdb;
    $table = $wpdb->prefix . 'customer_reviews';
    
    $query = $wpdb->prepare(
        "SELECT * FROM $table WHERE id = %d",
        intval($review_id)
    );
    
    return $wpdb->get_row($query);
}
